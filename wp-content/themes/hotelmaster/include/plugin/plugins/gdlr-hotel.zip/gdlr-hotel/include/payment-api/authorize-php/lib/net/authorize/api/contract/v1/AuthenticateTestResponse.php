<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing AuthenticateTestResponse
 */
class AuthenticateTestResponse extends ANetApiResponseType
{


}

